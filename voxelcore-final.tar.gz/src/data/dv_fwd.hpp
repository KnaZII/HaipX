#pragma once

namespace dv {
    class value;
    struct optionalvalue;
}
