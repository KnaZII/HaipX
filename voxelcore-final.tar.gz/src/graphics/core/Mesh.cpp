#include "graphics/core/Mesh.hpp"

 int MeshStats::meshesCount = 0;
 int MeshStats::drawCalls = 0;