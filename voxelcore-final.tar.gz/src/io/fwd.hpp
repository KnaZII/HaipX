#pragma once

namespace io {
    class path;
}
