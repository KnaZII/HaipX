#include "api_lua.hpp"

const luaL_Reg applib[] = {
    // see libcore.cpp an stdlib.lua
    {NULL, NULL}
};
