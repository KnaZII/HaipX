# *time* library

```python
time.uptime() -> float
```

Returns time elapsed since the engine started.

```python
time.delta() -> float
```

Returns time elapsed since the last frame.
